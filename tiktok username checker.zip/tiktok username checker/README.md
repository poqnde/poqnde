# Tiktok Username Checker

This is a simple to use Checker which is written in Python with aiohttp for the best results.

### New Update 2022/06/25 : Increased Speed and Fixed Timeout Error

You may consider combining my Tiktok Username Checker with my Random Character Generator for best Results: https://github.com/accomodate/random-character-generator

## Instructions

1) Download the Source Code

2) Open a Terminal / CMD

3) Run this Command in it :
   
```bash
pip install -r requirements.txt
```
   
4) The following steps should be easy.
   
   4.1) Input your Usernames into usernames.txt
   
   Doubleclick tiktok-username-checker.py and it should instantly start checking for available usernames.
   
   4.2) Available Usernames are saved into available.txt
   
## Common Errors and Fixes
       
1) Your pip is not recognized!

   --> Uninstall your current Python Version and download it again.
   Don't forget to tick the " Add to Path " Box. Fixed.
   
## Legal

This was merely a speedrun to demonstrate how username checkers work.

This is illegal if you use this without the consent of the owners (in this case, the TikTok team).

The software designed to perform website security testing.

The author is not responsible for any illegal use of these programs.

I am not accountable for anything you get into. I am not accountable for any of your actions.

This is 100% educational, please do not misuse this tool.
       
## Contact

Discord : enes#5555

Feel free to create a Pull Request. If there is an Error please open an Issue so I can look into it a.s.a.p! :) 
